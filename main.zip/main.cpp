// main.cpp

// Author: Ryan Canty

// Date: 11/4/15

// Course: CSC1610

// Description: This file plays the game Nim.  This program allows users to alternate turns and
// pick what pile they want tokens taken out of, whoever takes the last token is the winner.

// Input: Three user-defined strings collected from the standard input stream
// (keyboard).

// Output: The rearranged strings.

#include <cstdlib>
#include <iostream>
#include <cmath>
#include <cassert>

using namespace std;

const int INITIAL_PILE_SIZE = 10;
void playerTurn( int& );
void sizeOfPiles( int&, int&, int& );
int pileNumber();
int numOfTokens( int&, int&, int&, int& );
void makeMove( int&, int&, int&, int&, int& );
void isWinner( int& );

int main() 
{
    int pile1 = INITIAL_PILE_SIZE;
    int pile2 = INITIAL_PILE_SIZE;
    int pile3 = INITIAL_PILE_SIZE;
    int curPlayer = 1;
    int tokenSelect;
    int pileSelect;
    while( pile1 > 0 || pile2 > 0 || pile3 > 0 )
    {
        cout << " " << endl;
        playerTurn( curPlayer );
        sizeOfPiles( pile1, pile2, pile3 );
        int pileSelect = pileNumber();
        int tokenSelect = numOfTokens( pile1, pile2, pile2, pileSelect );
        makeMove( pile1, pile2, pile3, pileSelect, tokenSelect );
    }
    isWinner( curPlayer );

    return 0;
}

void sizeOfPiles( int& pile1, int& pile2, int& pile3 )
{
    cout << "Pile 1: " << pile1 << endl;
    cout << "Pile 2: " << pile2 << endl;
    cout << "Pile 3: " << pile3 << endl;
}

int pileNumber()
{
    int pileSelect;
    do
    {
        cout << "Which pile would you like to take tokens from? ";
        cin >> pileSelect;
        if( pileSelect > 3 || pileSelect < 0 )
        {
            cout << "That is an invalid pile number." << endl;
        }
    }
    while( pileSelect < 1 || pileSelect > 3 );
    return pileSelect;
}

int numOfTokens( int& pile1, int& pile2, int& pile3, int& pileSelect )
{
    /*int newTokenNumber;
    if( pileSelect == 1 )
    {
        newTokenNumber = pile1;
    }
    else if( pileSelect == 2 )
    {
        newTokenNumber = pile2;
    }
    else if( pileSelect == 3 )
    {
        newTokenNumber = pile3;
    }*/
    int tokenSelect;
    do
    {
        cout << "How many tokens? ";
        cin >> tokenSelect;
        if( tokenSelect > 10 || tokenSelect < 0 )
        {
            cout << "That is an invalid number of tokens." << endl;
        }
    }
    while( tokenSelect < 1 || tokenSelect > 10 );
    return tokenSelect;
}

void makeMove( int& pile1, int& pile2, int& pile3, int& pileSelect, int& tokenSelect)
{
    if( pileSelect == 1 )
    {
        pile1 -= tokenSelect;
    }
    else if( pileSelect == 2 )
    {
        pile2 -= tokenSelect;
    }
    else if( pileSelect == 3 )
    {
        pile3 -= tokenSelect;
    }

}

void playerTurn( int& curPlayer )
{
    if( curPlayer % 2 != 0 )
    {
        cout << "Player 1's turn:" << endl;
    }
    else if( curPlayer % 2 == 0 )
    {
        cout << "Player 2's turn:" << endl;
    }
    curPlayer++;
}

void isWinner( int& curPlayer )
{
    if( curPlayer %2 == 0 )
    {
        cout << "Player 1 wins!" << endl;
    }
    else if( curPlayer % 2 != 0 )
    {
        cout << "Player 2 wins!" << endl;
    }
}